#!/usr/bin/python3
# @Time    : 2025-02-15
# @Author  : Kevin Kong (kfx2007@163.com)

from yd.api import YD
from unittest import TestCase
import unittest


class TestOrder(TestCase):
    @classmethod
    def setUpClass(cls):
        cls.yd = YD(
            appkey="999999", appsecret="04d4ad40eeec11e9bad2d962f53dda9d", partner_id="529951202001", secret="Y4TQ3WBar9hpnw7As8xUZEReSuDdf2", sandbox=True
        )
        cls.order_no = "order123"

    def test_order_create(self):
        # Prepare test parameters
        appid = "000333"
        orderid = self.order_no
        backurl = "http://callback.url"
        sender = {
            "name": "Alice",
            "company": "Sender Co.",
            "province": "Sender Province",
            "city": "Sender City",
            "county": "Sender County",
            "address": "123 Sender St.",
            "postcode": "111111",
            "phone": "1234567890",
            "mobile": "0987654321",
        }
        receiver = {
            "name": "Bob",
            "company": "Receiver Co.",
            "province": "Receiver Province",
            "city": "Receiver City",
            "county": "Receiver County",
            "address": "云天路348号普洛斯国际物流园区二层12号库A1-2-12建议使用官方推荐[上门取件服务]寄回",
            "postcode": "222222",
            "phone": "9876543210",
            "mobile": "0123456789",
        }
        sendstarttime = "2025-02-16 10:00:00"
        # Extra parameter for testing optional kwargs
        extra_kwargs = {"weight": "10"}

        # Expected payload per create() method logic
        # expected_payload = {
        #     "appid": appid,
        #     "orderid": orderid,
        #     "backurl": backurl,
        #     "sender": sender,
        #     "receiver": receiver,
        #     "sendstarttime": sendstarttime,
        #     "weight": "10"
        # }

        # Execute the create method
        response = self.yd.order.create(
            appid, orderid, backurl, sender, receiver, sendstarttime, **extra_kwargs
        )
        self.assertEqual(response["result"], True, response)

    def test_order_cancel(self):
        data = {"appid": "000333", "backparam": "", "orderid": "order123"}
        response = self.yd.order.cancel(**data)
        self.assertEqual(response["result"], True, response)

    def test_order_rate(self):
        """
        Test the rate method by providing a rating score and comment for an existing order.
        """
        kwargs = {"startCity": "山东省", "endCity": "安徽省", "weight": 2.00}
        response = self.yd.order.rate(**kwargs)
        self.assertEqual(response.get("result"), True, response)
        
    def test_label_print(self):
        result = self.yd.order.label.print(self.parnet_id, self.secret, [self.order_no])
        print("++++")
        print(result)
        self.assertEqual(result["result"], True, result)



if __name__ == "__main__":
    unittest.main()
