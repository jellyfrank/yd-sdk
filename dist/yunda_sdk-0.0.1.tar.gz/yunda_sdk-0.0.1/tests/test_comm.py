#!/usr/bin/python3
# @Time    : 2025-02-15
# @Author  : Kevin Kong (kfx2007@163.com)

import json
import hashlib
from unittest.mock import patch, MagicMock
from yd.api import YD
from yd.comm.comm import Comm, URL, SANDBOXURL
import unittest


class TestComm(unittest.TestCase):
    
    @classmethod
    def setUpClass(cls):
        cls.yd = YD(appkey="999999", appsecret="04d4ad40eeec11e9bad2d962f53dda9d", sandbox=True)

    def test_get_sign(self):
        request_body = {"receiver":{"address":"云天路348号普洛斯国际物流园区二层12号库A1-2-12建议使用官方推荐[上门取件服务]寄回","province":"上海市","city":"上海市","name":"hollisterco官方旗舰店","county":"宝山区","mobile":"021-26094774"},"orderid":"PO161233156653669418","sender":{"address":"戚继光路655号5楼工程部","province":"浙江省","city":"金华市","name":"季欣怡","county":"义乌市","mobile":"15325912355"},"backurl":"https://bc.ulandian.com/partner/weixin/expressOrder/yundaNewOrderCallback","appid":"000333","weight":2,"backparam":"LANDIAN","remark":"【渠道订单】总部月结。需当面称重，使用韵镖侠打单。","sendstarttime":"2021-02-03 13:53:01"}
        sign = self.yd.comm.get_sign(request_body)
        self.assertEqual(sign, "c48d8e3130e2c3162d0bb8abada2df01")


if __name__ == "__main__":
    unittest.main()
