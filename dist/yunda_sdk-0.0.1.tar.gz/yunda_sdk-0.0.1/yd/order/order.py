#!/usr/bin/python3
# @Time    : 2025-02-15
# @Author  : Kevin Kong (kfx2007@163.com)

from yd.comm import Comm

class Order(Comm):
    """Order related API"""
    
    def create(self, appid: str, orderid: str, backurl: str, sender: dict, receiver: dict, sendstarttime: str, **kwargs):
        """
        Create an order using the order/pushOrder endpoint.
        
        Parameters:
            appid (str): 合作商app-key.
            orderid (str): 合作商订单号.
            backurl (str): 运单回传地址url.
            sender (dict): 寄件人信息, e.g., {
                "name": str,
                "company": str,
                "province": str,
                "city": str,
                "county": str,
                "address": str,
                "postcode": str,
                "phone": str,
                "mobile": str
            }
            receiver (dict): 收件人信息, e.g., {
                "name": str,
                "company": str,
                "province": str,
                "city": str,
                "county": str,
                "address": str,
                "postcode": str,
                "phone": str,
                "mobile": str
            }
            sendstarttime (str): 取件开始时间 (格式: yyyy-MM-dd HH:mm:ss).
            **kwargs: Optional parameters including:
                sendendtime, weight, size, value, freight, premium, other_charges, items, backparam, special, remark.
        
        Returns:
            dict: API response.
        """
        payload = {
            "appid": appid,
            "orderid": orderid,
            "backurl": backurl,
            "sender": sender,
            "receiver": receiver,
            "sendstarttime": sendstarttime
        }
        payload.update(kwargs)
        endpoint = "/openapi-api/v1/order/pushOrder"
        return self.post(endpoint, payload)
    
    def cancel(self, appid: str, orderid: str, backparam: str) -> dict:
        """
        Cancel an order using the order/cancelOrder endpoint.
        
        Parameters:
            appid (str): app_key.
            orderid (str): Order number.
            backparam (str, optional): Original return field.
            
        Returns:
            dict: API response.
            {'code': '0000', 'message': '请求成功', 'result': True, 'data': {'orderid': 'order123', 'backparam': None}}
        """
        payload = {
            "appid": appid,
            "orderid": orderid
        }
        if backparam is not None:
            payload["backparam"] = backparam
        endpoint = "/openapi-api/v1/order/cancelOrder"
        return self.post(endpoint, payload)
    
    def rate(self, startCity: str, endCity: str, weight: str) -> dict:
        """
        Get the shipping rate based on sender and receiver provinces and weight.
        
        Parameters:
            startCity (str): 寄件人省份/直辖市 （一级地址）.
            endCity (str): 收件人省份/直辖市 （一级地址）.
            weight (str): 重量（kg）.
        
        Returns:
            dict: API response.
            {'code': '0000', 'data': 17.0, 'message': '请求成功', 'result': True, 'sub_code': None, 'sub_msg': None}
        """
        payload = {
            "startCity": startCity,
            "endCity": endCity,
            "weight": weight
        }
        endpoint = "/openapi-api/v1/order/getFreightInfo"
        return self.post(endpoint, payload)
