#!/usr/bin/python3
# @Time    : 2025-02-15
# @Author  : Kevin Kong (kfx2007@163.com)

from turtle import end_fill
from yd.comm import Comm


class Label(Comm):
    """Label related API"""

    def print(self, partner_id: str, secret: str, orders: list):
        """
        Print the order parameters.

        参数:
            partner_id(String, 长度:30, 必填) - 韵达白马账号（合作网点提供，转发白马接口需使用）
            secret    (String, 长度:30, 必填) - 韵达白马账号的联调密码（合作网点提供，转发白马接口需使用）
            orders    (List,  必填)         - 订单详情(一批次只能传一个运单号)
        """
        payload = {
            "appid": self.appkey,
            "partner_id": partner_id,
            "secret": secret,
            "orders": orders,
        }
        endpoint = "/v1/bm/getPdfInfo"
        return self.post(endpoint, payload)
